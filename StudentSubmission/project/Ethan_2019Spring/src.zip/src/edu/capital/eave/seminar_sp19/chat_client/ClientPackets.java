package edu.capital.eave.seminar_sp19.chat_client;

public class ClientPackets {
	public static final int FATAL_ERROR_MESSAGE = 15;
	public static final int SEND_ENC_USER_MESSAGE = 0;
	
}
