package edu.capital.eave.seminar_sp19.chat_server;

public class ServerPackets {
	public static final int LOGIN = 0;
	public static final int LOGOUT = 255;
	public static final int SEND_MESSAGE = 1;
}
